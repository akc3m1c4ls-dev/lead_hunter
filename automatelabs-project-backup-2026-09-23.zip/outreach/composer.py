from google import genai
from google.genai.errors import ServerError

import json
import time

from config import GEMINI, MODEL


client = genai.Client(api_key=GEMINI)

MAX_RETRIES = 3
RETRY_DELAYS = [10, 30, 60]


def compose_email(lead: dict) -> dict | None:
    """
    Generate one personalised cold outreach email using
    Lead Hunter's stored analysis.

    Returns:
        {
            "subject": "...",
            "body": "..."
        }

    Nothing is sent here.
    """

    prompt = f"""
You write concise, professional B2B outreach emails for AutomateLabs,
a software automation company.

Your task is to write ONE personalised outreach email to the business
below.

The business has already been researched and analysed.
Use ONLY the supplied information.

BUSINESS

Name: {lead.get("business_name")}
Category: {lead.get("category")}
Location: {lead.get("location")}
Website: {lead.get("website")}

LEAD HUNTER ANALYSIS

Problems:
{lead.get("problems")}

Opportunities:
{lead.get("opportunities")}

Existing systems:
{lead.get("existing_systems")}

Target problem:
{lead.get("target_problem")}

Proposed solution:
{lead.get("proposed_solution")}

Evidence:
{lead.get("evidence")}

Pitch angle:
{lead.get("pitch_angle")}

Signals:
{lead.get("signals")}

Score:
{lead.get("score")}

Confidence:
{lead.get("confidence")}


EMAIL OBJECTIVE

Start a genuine conversation about ONE specific automation opportunity
that appears relevant to this business.

Do not try to sell every AutomateLabs service.


WRITING RULES

1. PERSONALISATION

The email must clearly be written for this specific business.

Use the supplied evidence, target problem and pitch angle.

Do not invent facts.

Do not claim you personally observed something unless it is supported
by the supplied information.


2. FOCUS

Choose ONE strong automation opportunity.

Do not list multiple unrelated services.


3. TONE

Professional, natural and concise.

Sound like a person who researched the business.

Do not sound like mass marketing.

Avoid exaggerated sales language.


4. LENGTH

Keep the email approximately 80-140 words.


5. OPENING

Avoid generic openings such as:

"I hope this email finds you well."

Do not begin with a long introduction about AutomateLabs.


6. VALUE

Briefly explain:

- what caught our attention
- what could potentially be improved
- what AutomateLabs could build or automate
- the practical benefit


7. UNCERTAINTY

The Lead Hunter analysis may contain hypotheses.

Never present uncertain information as confirmed fact.

When appropriate use language such as:

"It looks like..."
"From the information available..."
"I wondered whether..."
"There may be an opportunity to..."


8. CALL TO ACTION

End with a low-pressure invitation to discuss the idea.

Do not manufacture urgency.


9. SIGNATURE

Do NOT include an email signature.
The sending system will add it separately.


10. SUBJECT

Write a short, natural subject line.

Avoid spam-like subjects, excessive punctuation, emojis,
ALL CAPS, or clickbait.

11.LANGUAGE AND STRUCTURE

The email must contain the same message in THREE languages,
in this exact order:

    1. ESTONIAN
    2. RUSSIAN
    3. ENGLISH

Estonian is the primary version and must always appear first.

The Russian version must communicate the same meaning as the
Estonian version.

The English version must communicate the same meaning as the
Estonian version.

Do not introduce new facts, claims, services or promises in the
Russian or English versions.

Write naturally in each language. Do not produce awkward
word-for-word translations.

Separate the three versions clearly with these headings:

EESTI

РУССКИЙ

ENGLISH


WEBSITE

At the end of EACH language version include a short natural
invitation to learn more about AutomateLabs at:

https://automatelabs.me

Do not invent any other URLs.


CRITICAL ACCURACY RULES

Never invent software, APIs, payment providers, CRM systems,
technical architecture, internal processes, employee workflows,
or implementation details that are not explicitly present in
the supplied research.

For example, do not mention Stripe, HubSpot, Salesforce, Zapier,
specific APIs, or other technologies unless the supplied evidence
explicitly identifies them.

Separate observed facts from proposed ideas.

If proposing a technical solution, describe the capability rather
than inventing the technology used to implement it.

Never promise outcomes such as "instant", "guaranteed",
"error-free", or specific savings unless supported by evidence.


SUBJECT

Return one concise subject line in Estonian.

The subject should be natural and professional.
Do not use emojis, ALL CAPS, clickbait or excessive punctuation.


SIGNATURE

Do NOT generate an email signature.
The sending system will add the AutomateLabs signature separately.


Return structured data only.


Return structured data only.
"""

    response = None

    for attempt in range(MAX_RETRIES):

        try:
            response = client.models.generate_content(
                model=MODEL,
                contents=prompt,
                config={
                    "response_mime_type": "application/json",
                    "response_schema": {
                        "type": "OBJECT",
                        "properties": {
                            "subject": {
                                "type": "STRING",
                            },
                            "body": {
                                "type": "STRING",
                            },
                        },
                        "required": [
                            "subject",
                            "body",
                        ],
                    },
                },
            )

            break

        except ServerError as e:

            print(
                f"Gemini error "
                f"(attempt {attempt + 1}/{MAX_RETRIES}): {e}"
            )

            if attempt == MAX_RETRIES - 1:
                print("Gemini failed after retries.")
                return None

            delay = RETRY_DELAYS[attempt]

            print(
                f"Waiting {delay}s before retry..."
            )

            time.sleep(delay)

    if response is None:
        return None

    data = json.loads(response.text)

    return {
        "subject": data["subject"].strip(),
        "body": data["body"].strip(),
    }

if __name__ == "__main__":
    from outreach.selector import get_next_lead

    print("Selecting next lead...")

    lead = get_next_lead()

    if lead is None:
        print("No eligible leads found.")
        raise SystemExit(0)

    print(f"Selected: {lead['business_name']}")
    print(f"Email: {lead['email']}")
    print(f"Score: {lead['score']}")
    print()
    print("Generating draft with Gemini...")

    draft = compose_email(lead)

    if draft is None:
        print("Failed to generate draft.")
        raise SystemExit(1)

    print()
    print("=" * 70)
    print("OUTREACH DRAFT")
    print("=" * 70)
    print(f"To:      {lead['email']}")
    print(f"Subject: {draft['subject']}")
    print("-" * 70)
    print(draft["body"])
    print("=" * 70)